# Architecture

`GXW -> CFB reader -> parser -> PLC-IR -> deterministic analyzer -> GUI/CLI/report`

Evidence is attached to recovered structures. Unknown proprietary payloads are not reconstructed by guesswork.
