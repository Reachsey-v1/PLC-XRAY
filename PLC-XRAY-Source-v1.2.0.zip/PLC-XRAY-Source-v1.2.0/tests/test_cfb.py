from plcxray.cfb import CompoundFile, MAGIC
import pytest

def test_reject_non_cfb():
    with pytest.raises(ValueError): CompoundFile.from_bytes(b'not a gxw')

def test_magic_constant():
    assert len(MAGIC)==8
