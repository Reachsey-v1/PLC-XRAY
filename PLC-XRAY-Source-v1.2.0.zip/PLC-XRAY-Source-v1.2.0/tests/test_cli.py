from plcxray.cli import main

def test_cli_requires_command():
    import pytest
    with pytest.raises(SystemExit): main([])
