from plcxray.ir import Evidence, ProjectIR

def test_evidence_status():
    assert Evidence('CONFIRMED').status == 'CONFIRMED'

def test_ir_dict():
    x=ProjectIR('x.gxw','abc',3)
    assert x.to_dict()['sha256']=='abc'
