# Assets

This directory is reserved for application icons and future UI assets. The current build intentionally has no binary icon dependency so GitHub Actions remains reproducible without third-party image packages.
