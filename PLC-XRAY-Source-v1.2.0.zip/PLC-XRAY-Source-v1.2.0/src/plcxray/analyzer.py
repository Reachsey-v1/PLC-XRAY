from dataclasses import dataclass, asdict
from typing import List
from .ir import ProjectIR

@dataclass
class Finding:
    severity: str
    status: str
    title: str
    detail: str
    evidence: str = ""

def analyze(ir: ProjectIR) -> List[Finding]:
    out=[]
    if not ir.pous:
        out.append(Finding('INFO','NOT VERIFIED','No POU payload decoded','The importer found no decoded POU streams. Native GX Works verification is required.'))
    if not ir.labels:
        out.append(Finding('INFO','NOT VERIFIED','No label table recovered','No usable label declarations were recovered from label.xml.'))
    if ir.warnings:
        for w in ir.warnings: out.append(Finding('INFO','NOT VERIFIED','Importer warning',w))
    return out

def audit_writers(ir: ProjectIR):
    # Writer information is only populated when instruction decoding supplies it.
    return [d for d in ir.devices.values() if len(d.writers)>1]
