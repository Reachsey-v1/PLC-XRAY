"""Small dependency-free Compound File Binary reader used for GXW inspection."""
from dataclasses import dataclass
import struct
from typing import Dict, List, Optional

MAGIC = bytes.fromhex("D0CF11E0A1B11AE1")
FREE = 0xFFFFFFFF
END = 0xFFFFFFFE
FAT = 0xFFFFFFFD
DIFAT = 0xFFFFFFFC
NO_STREAM = 0

@dataclass
class DirEntry:
    name: str
    obj_type: int
    start_sector: int
    size: int
    child: int
    left: int
    right: int

class CompoundFile:
    def __init__(self, data: bytes):
        self.data = data
        self.sector_size = 512
        self.mini_sector_size = 64
        self.num_fat = 0
        self.first_dir = END
        self.first_mini_fat = END
        self.num_mini_fat = 0
        self.first_difat = END
        self.entries: List[DirEntry] = []
        self._fat: List[int] = []
        self._mini_fat: List[int] = []
        self._mini_stream = b""
        self._parse()

    @classmethod
    def from_bytes(cls, data: bytes):
        return cls(data)

    def _sector(self, n: int) -> bytes:
        off = 512 + n * self.sector_size
        return self.data[off:off+self.sector_size]

    def _parse(self):
        if len(self.data) < 512 or self.data[:8] != MAGIC:
            raise ValueError("Not a Compound File Binary (OLE/CFB) container")
        major = struct.unpack_from("<H", self.data, 26)[0]
        if major == 3:
            self.sector_size = 512
        elif major == 4:
            self.sector_size = 4096
        else:
            raise ValueError(f"Unsupported CFB major version: {major}")
        self.num_fat = struct.unpack_from("<I", self.data, 44)[0]
        self.first_dir = struct.unpack_from("<I", self.data, 48)[0]
        self.mini_sector_size = 1 << struct.unpack_from("<H", self.data, 32)[0]
        self.first_mini_fat = struct.unpack_from("<I", self.data, 60)[0]
        self.num_mini_fat = struct.unpack_from("<I", self.data, 64)[0]
        self.first_difat = struct.unpack_from("<I", self.data, 68)[0]
        difat = list(struct.unpack_from("<109I", self.data, 76))
        fat_sectors = [x for x in difat if x not in (FREE, END)]
        nxt = self.first_difat
        entries_per = self.sector_size // 4 - 1
        while nxt not in (FREE, END) and nxt < 0xFFFFFF00:
            sec = self._sector(nxt)
            vals = struct.unpack_from(f"<{entries_per}I", sec, 0)
            fat_sectors.extend(x for x in vals if x not in (FREE, END))
            nxt = struct.unpack_from("<I", sec, entries_per*4)[0]
        fat_sectors = fat_sectors[:self.num_fat]
        self._fat = []
        for s in fat_sectors:
            sec = self._sector(s)
            self._fat.extend(struct.unpack_from(f"<{self.sector_size//4}I", sec, 0))
        self._read_directory()
        self._read_mini_fat()
        root = next((e for e in self.entries if e.obj_type == 5), None)
        if root and root.size:
            self._mini_stream = self.read_chain(root.start_sector, root.size)

    def read_chain(self, start: int, size: Optional[int] = None) -> bytes:
        if start in (FREE, END) or start >= len(self._fat):
            return b""
        out = bytearray(); seen=set(); cur=start
        while cur not in (FREE, END) and cur < len(self._fat) and cur not in seen:
            seen.add(cur); out.extend(self._sector(cur)); cur=self._fat[cur]
        return bytes(out if size is None else out[:size])

    def _read_directory(self):
        raw = self.read_chain(self.first_dir)
        self.entries=[]
        for off in range(0, len(raw)-127, 128):
            chunk=raw[off:off+128]
            name_len=struct.unpack_from("<H",chunk,64)[0]
            if name_len < 2: continue
            name=chunk[:name_len-2].decode("utf-16le", errors="replace")
            obj=chunk[66]
            left,right,child=struct.unpack_from("<III",chunk,68)
            start=struct.unpack_from("<I",chunk,116)[0]
            size=struct.unpack_from("<Q",chunk,120)[0]
            self.entries.append(DirEntry(name,obj,start,size,child,left,right))

    def _read_mini_fat(self):
        if self.first_mini_fat in (FREE, END) or not self.num_mini_fat:
            return
        raw=self.read_chain(self.first_mini_fat, self.num_mini_fat*self.sector_size)
        self._mini_fat=list(struct.unpack_from(f"<{len(raw)//4}I",raw,0)) if raw else []

    def names(self) -> List[str]:
        return [e.name for e in self.entries]

    def _entry(self,name):
        for e in self.entries:
            if e.name==name: return e
        raise KeyError(name)

    def read(self,name: str) -> bytes:
        e=self._entry(name)
        if e.obj_type != 2: raise ValueError(f"Not a stream: {name}")
        if e.size < 4096 and self._mini_stream and self._mini_fat:
            out=bytearray(); cur=e.start_sector; seen=set()
            while cur not in (FREE,END) and cur < len(self._mini_fat) and cur not in seen:
                seen.add(cur); off=cur*self.mini_sector_size
                out.extend(self._mini_stream[off:off+self.mini_sector_size]); cur=self._mini_fat[cur]
            return bytes(out[:e.size])
        return self.read_chain(e.start_sector,e.size)
