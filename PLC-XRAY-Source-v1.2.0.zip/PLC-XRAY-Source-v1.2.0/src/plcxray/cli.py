import argparse, json
from .parser import parse_project
from .analyzer import analyze

def main(argv=None):
    p=argparse.ArgumentParser(prog='plcxray',description='Read-only Mitsubishi GXW engineering inspector')
    sub=p.add_subparsers(dest='cmd',required=True)
    for name in ('inspect','devices','report'):
        sp=sub.add_parser(name); sp.add_argument('project')
    args=p.parse_args(argv)
    ir=parse_project(args.project)
    if args.cmd=='inspect':
        print(json.dumps({'path':ir.path,'sha256':ir.sha256,'size':ir.file_size,'streams':len(ir.streams),'pous':len(ir.pous),'labels':len(ir.labels),'devices':len(ir.devices),'warnings':ir.warnings},indent=2))
    elif args.cmd=='devices':
        print(json.dumps({k:{'kind':v.kind,'label':v.label,'evidence':v.evidence.status} for k,v in sorted(ir.devices.items())},indent=2))
    else:
        print(json.dumps({'project':ir.to_dict(),'findings':[f.__dict__ for f in analyze(ir)]},indent=2,default=str))
    return 0
if __name__=='__main__': raise SystemExit(main())
