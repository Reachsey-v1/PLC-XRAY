from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any

STATUS = ("CONFIRMED", "INFERRED", "NOT VERIFIED", "UNKNOWN", "UNSUPPORTED")

@dataclass(frozen=True)
class Evidence:
    status: str = "NOT VERIFIED"
    source: str = ""
    detail: str = ""
    def __post_init__(self):
        if self.status not in STATUS:
            raise ValueError(f"invalid evidence status: {self.status}")

@dataclass
class DeviceRef:
    device: str
    kind: str = "UNKNOWN"
    label: Optional[str] = None
    comment: Optional[str] = None
    readers: List[str] = field(default_factory=list)
    writers: List[str] = field(default_factory=list)
    evidence: Evidence = field(default_factory=Evidence)

@dataclass
class Instruction:
    mnemonic: str
    operands: List[str] = field(default_factory=list)
    source: Evidence = field(default_factory=Evidence)

@dataclass
class POU:
    name: str
    stream_id: Optional[str] = None
    size: int = 0
    instructions: List[Instruction] = field(default_factory=list)
    evidence: Evidence = field(default_factory=Evidence)

@dataclass
class ProjectIR:
    path: str
    sha256: str
    file_size: int
    format: str = "GXW/CFB"
    streams: List[str] = field(default_factory=list)
    pous: List[POU] = field(default_factory=list)
    devices: Dict[str, DeviceRef] = field(default_factory=dict)
    labels: Dict[str, str] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
