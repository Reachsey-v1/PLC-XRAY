"""Read-only GXW importer. Unsupported proprietary payloads are explicitly marked."""
from pathlib import Path
import hashlib, re, xml.etree.ElementTree as ET
from .cfb import CompoundFile, MAGIC
from .ir import ProjectIR, POU, DeviceRef, Evidence

DEVICE_RE = re.compile(r'\b([XYMSTCDZR][0-9A-Fa-f]+)\b')

class GXWProject:
    def __init__(self, path: str):
        self.path=Path(path)
        self.data=self.path.read_bytes()
        self.sha256=hashlib.sha256(self.data).hexdigest()
        self.cfb=CompoundFile.from_bytes(self.data)
        self.nested=None
        if '_hdb' in self.cfb.names():
            try: self.nested=CompoundFile.from_bytes(self.cfb.read('_hdb'))
            except Exception: self.nested=None

    def inspect(self) -> ProjectIR:
        ir=ProjectIR(str(self.path),self.sha256,len(self.data))
        ir.streams=self.cfb.names()
        if self.nested: ir.warnings.append('Nested _hdb container detected; proprietary POU payload decoding is partial/read-only.')
        self._labels(ir)
        self._pous(ir)
        self._device_refs(ir)
        return ir

    def _labels(self,ir):
        if 'label.xml' not in self.cfb.names(): return
        try:
            root=ET.fromstring(self.cfb.read('label.xml'))
            for elem in root.iter():
                attrs={str(k):str(v) for k,v in elem.attrib.items()}
                vals=list(attrs.values())
                dev=next((v for v in vals if DEVICE_RE.fullmatch(v)),None)
                name=attrs.get('szName') or attrs.get('name') or attrs.get('label')
                if dev and name: ir.labels[dev]=name
        except Exception as e: ir.warnings.append(f'label.xml parse warning: {e}')

    def _pous(self,ir):
        if not self.nested: return
        # GX Works stores many project objects under numeric streams in _hdb.
        # projectdatalist.xml provides the authoritative ID -> logical filename map.
        mapping = {}
        if 'projectdatalist.xml' in self.cfb.names():
            try:
                root = ET.fromstring(self.cfb.read('projectdatalist.xml'))
                for row in root.iter():
                    vals = {c.tag.split('}')[-1]: (c.text or '') for c in row}
                    iid, name = vals.get('iID'), vals.get('szName')
                    if iid and name: mapping[iid] = vals
            except Exception as e:
                ir.warnings.append(f'projectdatalist.xml parse warning: {e}')
        for sid, vals in mapping.items():
            name = vals.get('szName','')
            if not name.lower().endswith('.pou'): continue
            if vals.get('bScrapFlag','false').lower() == 'true': continue
            try: size = next(e.size for e in self.nested.entries if e.name == sid)
            except StopIteration: size = 0
            ir.pous.append(POU(name,sid,size,evidence=Evidence('CONFIRMED','projectdatalist.xml + _hdb/'+sid, 'POU object mapped from project metadata; ladder framing remains proprietary/not fully decoded.')))
        # Fallback for any directly named POU stream in a future GXW variant.
        known={p.stream_id for p in ir.pous}
        for e in self.nested.entries:
            if e.obj_type==2 and e.name.lower().endswith('.pou') and e.name not in known:
                ir.pous.append(POU(e.name,e.name,e.size,evidence=Evidence('NOT VERIFIED','_hdb/'+e.name,'Directly named POU stream located; metadata mapping unavailable.')))

    def _device_refs(self,ir):
        for name in self.cfb.names():
            if name in ('label.xml','user.xml','history.xml') or name.startswith('_'): continue
            try: raw=self.cfb.read(name)
            except Exception: continue
            text=raw.decode('utf-8',errors='ignore')
            for dev in set(DEVICE_RE.findall(text)):
                if dev not in ir.devices:
                    kind=dev[0].upper()
                    ir.devices[dev]=DeviceRef(dev,kind,ir.labels.get(dev),evidence=Evidence('CONFIRMED',name,'Device token found in project stream.'))
        for dev,label in ir.labels.items():
            if dev not in ir.devices:
                ir.devices[dev]=DeviceRef(dev,dev[0].upper(),label,evidence=Evidence('CONFIRMED','label.xml','Label/device declaration.'))
            else: ir.devices[dev].label=label

def parse_project(path: str) -> ProjectIR:
    return GXWProject(path).inspect()
