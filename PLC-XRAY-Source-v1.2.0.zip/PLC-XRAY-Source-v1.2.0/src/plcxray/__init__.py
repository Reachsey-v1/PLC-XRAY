"""PLC-XRAY: read-only Mitsubishi PLC project inspection toolkit."""
__version__ = "1.2.0"
